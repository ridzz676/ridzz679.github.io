export default function AdminPage() {
  return <div className="p-4">Halaman Admin Panel</div>;
}