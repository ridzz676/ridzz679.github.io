export default function CheckoutPage() {
  return <div className="p-4">Halaman Checkout</div>;
}