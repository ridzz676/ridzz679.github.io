export default function HomePage() {
  return <div className="p-4">Selamat datang di RIDZZ X RIPZ STORE</div>;
}